
import { Text, View, TextInput, Button, Alert } from 'react-native';
import React, {useState} from 'react';
import Logo from './components/Logo';


export default function App() {
  function buttonClicked() {
    Alert.alert("button clicked");
}
  const [fname, setFname] = useState("Grace");
  const [lname, setLname] = useState("Moore");
  const [dob, setDob] = useState("21 January 2004");

  return (
    <View>
      <Logo/>
      <TextInput placeholder="Enter your firstname" onChangeText={(val) => setFname(val)}/>
      <TextInput placeholder="Enter your lastname" onChangeText={(val) => setLname(val)}/>
      <TextInput placeholder="Enter your date of birth" onChangeText={(val) => setDob(val)}/>
      <Text>Hello {fname} {lname}. You were born on {dob}</Text>
      <Button title="SUBMIT" onPress={buttonClicked}/>
    </View>
       
  )
}